@extends ('layout.index')
@section('content')


<form method="POST" action="{{route('paciente.crear')}}">
            @csrf
            <h4>Nuevo Paciente</h4>
           
            <input type="text" name="nombre"></input>
            <input type="text" name="apellido"></input>
            <input type="text" name="dni"></input>
            <input type="date" name="fecha_nacimiento"></input>
            <input type="submit" value="Añadir"></input>
            </form>
        </article>

        @endsection