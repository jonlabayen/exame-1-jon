<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

       

        <style>
            
        </style>
    </head>
    <body>

    <nav style="display: flex; margin-left: 20%; list-style:none;"> 
        <li>
            <a >Crear paciente</a>
        </li>

        <li style="margin-left: 20%; list-style:none;">
            <a>Crear Doctor</a>
        </li>

        <li style="margin-left: 20%; list-style:none;">
            <a>Eliminar doctor</a>
        </li>
    </nav>


    <!-- <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            
        </div> -->


        <form method="POST" action="<?php echo e(route('paciente.crear')); ?>">
            <?php echo csrf_field(); ?>
            <h4>Nuevo Paciente</h4>
           
            <input type="text" name="nombre"></input>
            <input type="text" name="apellido"></input>
            <input type="text" name="dni"></input>
            <input type="date" name="fecha_nacimiento"></input>
            <input type="submit" value="Añadir"></input>
            </form>
        </article>


        
        
    </body>
</html><?php /**PATH /var/www/ExamenLaravel/examen_jon/resources/views/layout/index.blade.php ENDPATH**/ ?>