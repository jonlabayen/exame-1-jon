<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;


class ConsultaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        


        // $doctoresN = ['jon', 'unai', 'imanol', 'ekaitz'];
        // $doctoresA = ['a', 'b', 'c', 'd'];

        // for ($i = 0; $i < 2; $i++) {
        //     $numpacientes = random_int(1, 10);
        //     DB::table('tasks')->insert([
        //         'nombre' => $doctoresN[$i],
        //         'apellido' => $doctoresA[$i],
        //         'num_pacientes'=>$numpacientes,

        //     ]);



    }


    
}


