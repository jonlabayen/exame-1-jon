<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class PacienteFactoriaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
        //     'nombre' -> $this->faker->word();
        //     'apellido' -> $this->faker->word();
        ];
    }
}
